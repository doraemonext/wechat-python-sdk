# -*- coding: utf-8 -*-

from basic import WechatBasic